# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class GaProductDiscount(models.Model):
    _inherit = 'product.template'

    product_lines = fields.One2many('ga.product.lines', 'product_id', string='Discount Lines')


class GaProductLines(models.Model):
    _name = 'ga.product.lines'

    product_id = fields.Many2one('product.template', string='Discount', ondelete='cascade')
    discount = fields.Float(string='Discount%')
    discount_to = fields.Float(string='Discount To%')
    discount_from = fields.Float(string='Discount From%')
    groups = fields.Many2one('res.groups', string='User Group')


class GAProductDiscountOnchange(models.Model):
    _inherit = 'sale.order.line'

    product_lines_id = fields.Many2one('ga.product.lines')
    groups_id = fields.Many2one(related='product_lines_id.groups')

    @api.onchange('discount')
    def onchange_discount(self):
        if self.product_id:
            for group_id, xml_id in self.product_id.product_lines.mapped('groups')._get_external_ids().items():
                if self.env.user.has_group(xml_id[0]):
                    amount_discount = self.discount
                    amount_discount_to = self.product_id.product_lines.discount_to
                    amount_discount_from = self.product_id.product_lines.discount_from
                    if not amount_discount_from <= amount_discount <= amount_discount_to:
                        raise ValidationError(
                            _('Invalid value please enter between within range'))

