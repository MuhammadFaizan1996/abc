# -*- coding: utf-8 -*-
{
    'name': "Ga Discount Configuration",

    'summary': """
        Add misc functionality""",

    'description': """

    """,

    'author': "Gapps",
    'website': "",

    'category': '',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'sale'],

    # always loaded
    'data': [
            'security/group.xml',
        'security/ir.model.access.csv',
        'view/view.xml'
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
}